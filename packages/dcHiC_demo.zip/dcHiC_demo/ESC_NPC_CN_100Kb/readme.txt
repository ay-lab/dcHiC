1. input.ES_NPC_CN.txt shows the files required to run dcHiC.
The Hi-C matrix files are not provided in this demo directory
due to their large sizes.

2. run_dchic.sh script shows the step by step implementation of
dcHiC starting from a matrix file. As the input Hi-C matrix files
are absent, dcHiC will start from step 2 and then continue. Please
read the comments in the run_dchic.sh script for further details.

3. The data directory contains the 100Kb bed file required by dcHiC. 
Users can put their Hi-C matrices inside this directory and can 
run their analysis.

4. The EXPECTED_OUTPUT directory contains the primary outputs from
step 3, 6 and 7 of the demo script. The run_dchic.sh script should generate 
the same primary results provided in the EXPECTED_OUTPUT directory. 

5. *_pca directories contain the input pc.txt files for each 
chromosome as an output from step 1 of dcHiC.

6. DifferentialResult directory is the place where dcHiC will write 
results.
