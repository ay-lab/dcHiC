## Information
This is a demo directory to test dcHiC tool. As a 
testing example principal component (pc) values for 
mouse ESC (4 replicates), NPC (3 replicates) and CN 
(5 replicates) are provided in the ESC_NPC_CN_100Kb.
The same directory contains the run_dchic.sh script
to recreate the results.  

The scripts directory contains the basic but necessary 
scripts to reproduce the results while packages directory
contains the accessory programs that needs to be installed 
before the dcHiC run. 

## HOW TO INSTALL dcHiC

			OPTION 1
		
We recommend using Conda to install all dependencies in a virtual environment. 
The suggested path is using the appropriate Miniconda distribution. To install, 
go to the directory of your choice and run:

Installation Instructions
________________________
git clone https://github.com/ay-lab/dcHiC
cd dcHiC
conda env create -f ./packages/dchic.yml
conda activate dchic


                        OPTION 2

To run dcHiC through manual installation, ensure that you have all the R and Python 
packages below installed. dcHiC requires the following packages - 

R environment (R >= 4 version): (Dependencies from CRAN)
_______________________________________
Rcpp
RcppEigen
BH
BiocManager
optparse
bench
bigstatsr
bigreadr
robust
data.table
networkD3
depmixS4
rjson
R.utils

(Dependencies from Bioconductor)
________________________________
limma
IHW

(Local dependencies - provided under packages folder)
____________________________________________________
hashmap_0.2.2.tar.gz
functionsdchic_1.0.tar.gz

python environment:
___________________
igv-reports


Installation Instructions
________________________
step 1: After extracting the zip file, go to packages folder -
cd packages

step 2: execute the installPackages.sh script - 
chmod +x installPackages.sh
./installPackages.sh /<path to R>/<4.0.1 or greater>/bin
e.g, ./installPackages.sh /share/apps/R/4.0.1/bin

This step should take 5-10 minutes depending on your internet speed and configuration.


			BEDTOOLS REQUIREMENT

dcHiC requires bedtools, follow this page to install the package.
bedtools should be accessible via $PATH.
https://bedtools.readthedocs.io/en/latest/content/installation.html



HOW TO RUN dcHiC
________________________


TEST RUN - Comparison of ESC, NPC and CN at 100kb resolution

Please go the ESC_NPC_CN_100Kb directory for the test run.
To generate the result run the following script as -

chmod +x run_dchic.sh
./run_dchic.sh /<path to R>/<4.0.1 or greater>/bin
e.g, ./run_dchic.sh /share/apps/R/4.0.1/bin

EXPECTED RUNTIME: This run should take 10-15 minutes. Note that, in order to keep this 
example simple to demonstrate the core functionalities of dcHiC, we have removed the
initial PCA step to call compartments as well as the differential chromatin 
interaction calling step. 

EXPECTED OUTPUT OF THE TEST RUN
_________________________________

We have already provided the expected output files 
and folders underneath ESC_NPC_CN_100Kb\EXPECTED_OUTPUT for this test run. These 
include:

- fdr_result/ : This folder lists the differential compartment calling output. Files 
with ".Filtered" tag represent statistically significant differences at FDR 1%. We
report both the original PC scores as well as quantile normalized scores together 
with all other dcHiC statistics. 
- geneEnrichment/ : This folder contains the list of genes that are overlapping with 
differential compartment bins that are in the A compartment and have the highest 
compartment score for that cell type across all others. These genes can then be used
to perform GO term enrichment analysis. 
- viz/ : This folder contains standalone visualizations for compartment scores 
and differential compartment statistics as tracks on the IGV browser. One or multiple
HTML files may be created under subfolders depending on your selections. Simply 
clicking the HTML file should open a web browser window with results loaded.

In addition, when you run the code yourself you should be able to see the above result
folders and other intermediate files under the ESC_NPC_CN_100Kb\DifferentialResult 
folder. These include chromosome by chromosome original and quantile normalized 
compartment scores for each cell type (e.g., NPC_data/) as well as for all cell types
combined (PcOri/ or PcQnm/). 

For more details please visit https://github.com/ay-lab/dcHiC  
