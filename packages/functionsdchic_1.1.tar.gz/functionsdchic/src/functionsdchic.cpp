#include "iostream"
#include "numeric"
#include "vector"
#include "cmath"
#include "fstream"
#include "sstream"
#include "string"
#include "iterator"
#include "Rcpp.h"
#include "RcppEigen.h"
#include "unordered_map"
#include "BMAcc.h"

using namespace Rcpp;
using namespace std;
// [[Rcpp::depends(RcppEigen)]]

// [[Rcpp::export]]
NumericMatrix fbm2mat(Environment fbm) {
  
  XPtr<FBM> xpMat = fbm["address"];
  BMAcc<double> macc(xpMat);
  
  int n = macc.nrow();
  int m = macc.ncol();
  
  NumericMatrix res(n,m);
  for (int i = 0; i < n; i++)
    for(int j = 0; j < m; j++)
      res(i,j) = macc(i,j);
  
  return res;
}

// [[Rcpp::export]]
int createtransijk (std::string matfile, std::string bedfile, std::string outfile, std::string chrom) {
  std::unordered_map<int, int> oldTonew_index;
 
  std::ifstream bedf(bedfile.c_str());
  if (!bedf.good()) {
    std::cout << "Bad trans bed file, quiting!" << std::endl;
    return 1;
  }

  std::string chr;
  int start, end, index;
  int cis_chr_count = 0;
  int trans_chr_count = 0;
  int cis_start, cis_end;

  std::cout<<"Reading the "<<bedfile<<" file and reindexing "<<chrom<<"\n";
  while (bedf >> chr >> start >> end >> index) {
    if (chrom.compare(chr) == 0) {
      cis_chr_count = cis_chr_count + 1;
      if (cis_chr_count == 1) {
        cis_start = index;
      }
      cis_end = index;
      oldTonew_index.insert({index, cis_chr_count});
    } else {
      trans_chr_count = trans_chr_count + 1;
      oldTonew_index.insert({index, trans_chr_count});
    }  
  }
  bedf.close();
  std::cout<<"Reindexing complete\n";

  std::ifstream matf(matfile.c_str());
  if (!matf.good()) {
    std::cout << "Bad interaction file, quiting!" << std::endl;
    return 1;
  }

  std::cout<<"Reading the matrix file "<<matfile<<"\n";
  std::ofstream transf;
  transf.open(outfile.c_str());
  int i, j, k;
  while (matf >> i >> j >> k) {
    int i_new = oldTonew_index[i];
    int j_new = oldTonew_index[j];
    if ((i >= cis_start && i <= cis_end) && (j < cis_start || j > cis_end)) {
      transf << j_new << "\t" << i_new << "\t" << k << "\n";
    } else if ((j >= cis_start && j <= cis_end) && (i < cis_start || i > cis_end)) {
      transf << i_new << "\t" << j_new << "\t" << k << "\n";
    }
  }
  matf.close();
  transf.close();
  std::cout<<"Written "<<outfile<<"\n";
}

// [[Rcpp::export]]
NumericMatrix ijk2mat(NumericMatrix ijk, int row_size, int col_size) {
  NumericMatrix mat_obj(row_size, col_size);
  for (int u = 0; u < ijk.nrow(); u++) {
    int x = ijk(u,0) - 1;
    int y = ijk(u,1) - 1;
    mat_obj(x,y) = ijk(u,2);
    mat_obj(y,x) = ijk(u,2);
  }
  return(mat_obj);
}

// [[Rcpp::export]]
NumericMatrix eigenMapMatMult(NumericMatrix zm_blk1, NumericMatrix zm_blk2){
  const Eigen::Map<Eigen::MatrixXd> A(Rcpp::as<Eigen::Map<Eigen::MatrixXd>>(zm_blk1));
  const Eigen::Map<Eigen::MatrixXd> B(Rcpp::as<Eigen::Map<Eigen::MatrixXd>>(zm_blk2));
  Eigen::MatrixXd C = A.transpose() * B;
  return Rcpp::wrap(C);
}

// [[Rcpp::export]]
List zmat (NumericMatrix zm, NumericVector s, NumericVector e, int check_zmat) {

  int n = (((s.size() * s.size()) - s.size())/2) + s.size() + 1;
  List L(n);
  int rownum = zm.nrow() - 1;
  std::cout<<"Performing block wise correlation calculation\t";
  int c = 0;
  for(int u = 0; u < s.size(); u++) {
    for(int v = u; v < s.size(); v++) {
      //std::cout<<"Calculating Block "<<u<<" vs "<<"Block "<<v<<" correlation, ";
      NumericMatrix zm_block1 = zm(Range(0,rownum),Range(s[u],e[u]));
      NumericMatrix zm_block2 = zm(Range(0,rownum),Range(s[v],e[v]));
      NumericMatrix block_cor = eigenMapMatMult(zm_block1, zm_block2) / rownum;
      L[c] = List::create(Named("mat") =  block_cor, _["row.start"] = s[u], _["row.end"] = e[u], _["col.start"] = s[v], _["col.end"] = e[v]);
      c = c + 1;
    }
  }
  if (check_zmat == 1) {
    L[c] = List::create(Named("zmat") = zm);
  } else if (check_zmat == 0) {
    L[c] = List::create(Named("zmat") = 0);
  }
  std::cout<<" : complete!\n";
  return L;
}

// [[Rcpp::export]]
List oe2cor(NumericMatrix m, NumericVector s, NumericVector e, int check_oe2cor, int check_cov) {

  std::cout<<"Matrix dimension "<<m.nrow()<<" X "<<m.ncol()<<"\n";
  std::cout<<"Performing Z transformation\t";
  NumericMatrix zm(m.nrow(),m.ncol());
  std::vector<double> col_coverage(m.ncol());

  for(int i = 0; i < m.ncol(); i++) {

    // Calculate mean, sd and Z transformation
    Rcpp::NumericVector col_vec = m(_,i);
    std::vector<double> colv = as<std::vector<double>>(col_vec);
    double sum  = std::accumulate(colv.begin(), colv.end(), 0.0);
    double mean = sum / colv.size();
    std::vector<double> diff(colv.size()); 
    std::transform(colv.begin(), colv.end(), diff.begin(), std::bind2nd(std::minus<double>(), mean));
    double sq_sum = std::inner_product(diff.begin(), diff.end(), diff.begin(), 0.0);
    int n = colv.size() - 1;
    double stdev = std::sqrt(sq_sum / n);
    if (stdev > 0) {
      Rcpp::NumericVector x = col_vec - mean;
      zm(_,i) = x/stdev;   
    } else { 
      NumericVector v (m.nrow());
      zm(_,i) = v;
    }
    if (check_cov == 1) {
      col_coverage[i] = sum;
    }
  }
  std::cout<<" : complete!\n";
  if (check_cov == 0) {
    List result = zmat(zm, s, e, check_oe2cor);
    return(result);

  } else if (check_cov == 1) {
    List result = List::create(Named("zcor") =  zmat(zm, s, e, check_oe2cor), _["coverage"] = col_coverage);
    return(result);
  }
}

// [[Rcpp::export]]
List transmat (std::string transfile, NumericVector rbins, NumericVector rbine, NumericVector cbins, NumericVector cbine, int rows, int cols) {

  NumericMatrix m(rows, cols);
  std::ifstream trans(transfile.c_str());
  if (!trans.good()) {
    std::cout << "Bad trans interaction file, quiting!" << std::endl;
    return 1;
  }

  //Reading and assigning the trans count
  std::cout<<"Reading the "<<transfile<<"\t";
  int row_index, col_index, count;
  while (trans >> row_index >> col_index >> count) {
    int r = row_index - 1;
    int c = col_index - 1;
    m(r, c) = count;
    //m(row_index, col_index) = count;
  }
  std::cout<<" : complete!\n";

  //Reduce the size of the matrix by merging continious rows defind by user
  NumericMatrix mreduced(rbins.size(), cols);
  std::cout<<"Reducing the matrix rows to "<<rbins.size()<<" X "<<cols<<"\n";
  for(int i = 0; i < rbins.size(); i++) {
    int u = rbins[i];
    int v = rbine[i];
    Rcpp::NumericMatrix rmat = m(Range(u,v),_);
    for(int j = 0; j < cols; j++) {
      Rcpp::NumericVector col_vec = rmat(_,j);
      std::vector<double> colv = as<std::vector<double>>(col_vec);
      mreduced(i,j) = std::accumulate(colv.begin(), colv.end(), 0.0);
    }
  }
  int check_transmat = 0;
  int check_coverage = 1;
  return(oe2cor(mreduced, cbins, cbine, check_transmat, check_coverage));
}
