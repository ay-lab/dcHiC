library(testthat)
library(hashmap)

test_check("hashmap")
