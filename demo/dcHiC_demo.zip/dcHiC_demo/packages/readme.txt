#To install the dependencies manually, ensure that you have the following R packages installed from CRAN or Bioconductor:
Rcpp
RcppEigen
BH
optparse
bench
bigstatsr
bigreadr
robust
data.table
networkD3
depmixS4
rjson
R.utils

limma (bioconductor)
IHW (bioconductor)

#Check which packages are already installed. If you get character(0) then you're all set, otherwise install the packages shown in the output.
#Please use the checkpackages.sh script to check or use the following code - 

$ Rscript -e 'plist <- c("functionsdchic","hashmap","R.utils","Rcpp","RcppEigen","BH","optparse","bench","bigstatsr","bigreadr","robust","data.table","networkD3","depmixS4","rjson","limma","IHW"); setdiff(plist,basename(find.package(plist)))'

#Install the CRAN packages. You can install one by one (preferred) or in a batch -
#Use the installCRANpackages.r script to install the CRAN packages one at a time - 
$ Rscript installCRANpackages.r <package name>

#Or by batch (all or missing ones)
$ Rscript -e 'install.packages(c("Rcpp","RcppEigen","BH","optparse","bench","bigstatsr","bigreadr","robust","data.table","networkD3","depmixS4","rjson"), repos="https://cloud.r-project.org")'

#For bioconductor install (Within R enviorment)-
if (!require("BiocManager", quietly = TRUE)) 
  install.packages("BiocManager")
BiocManager::install("limma")
BiocManager::install("IHW")

#R packages provided - 
hashmap_0.2.2.tar.gz
functionsdchic_1.0.tar.gz

#Install the provided packages as (Make sure the Rscript and R versions are the same) -
R CMD INSTALL hashmap_0.2.2.tar.gz
R CMD INSTALL functionsdchic_1.0.tar.gz

#Also dcHiC requires bedtools, follow this page to install the package. 
#bedtools should be accesible via $PATH 
https://bedtools.readthedocs.io/en/latest/content/installation.html

#All the packages are tested in R 3.3.3 and should be fine for higher versions too

#For detail or help in installation issues please visit https://github.com/ay-lab/dcHiC
#For conda installation, do the following -
git clone https://github.com/ay-lab/dcHiC
conda env create -f ./packages/dchic.yml
conda activate dchic
