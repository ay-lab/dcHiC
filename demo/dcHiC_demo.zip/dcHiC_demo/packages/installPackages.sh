RPATH=$1
$RPATH/Rscript --version

echo "Installing"
echo $RPATH/Rscript -e 'install.packages(c("R.utils","Rcpp","RcppEigen","BH","optparse","bench","bigstatsr","bigreadr","robust","data.table","networkD3","depmixS4","rjson"), repos="https://cloud.r-project.org")'
$RPATH/Rscript -e 'install.packages(c("R.utils","Rcpp","RcppEigen","BH","optparse","bench","bigstatsr","bigreadr","robust","data.table","networkD3","depmixS4","rjson"), repos="https://cloud.r-project.org")'

echo $RPATH/Rscript -e 'BiocManager::install("limma")'
$RPATH/Rscript -e 'BiocManager::install("limma")'

echo $RPATH/Rscript -e 'BiocManager::install("IHW")'
$RPATH/Rscript -e 'BiocManager::install("IHW")'

echo $RPATH/R CMD INSTALL hashmap_0.2.2.tar.gz
$RPATH/R CMD INSTALL hashmap_0.2.2.tar.gz

echo "
Note: If you face an issue while installing the
hashmap package with BH library, then please run the steps -

	$RPATH/Rscript -e 'remove.packages(\"BH\")'

	wget http://cran.nexr.com/src/contrib/BH_1.66.0-1.tar.gz

	$RPATH/R CMD INSTALL BH_1.66.0-1.tar.gz

	$RPATH/R CMD INSTALL hashmap_0.2.2.tar.gz

If you didn't received any error, please ignore the message

"



echo $RPATH/R CMD INSTALL functionsdchic_1.0.tar.gz
$RPATH/R CMD INSTALL functionsdchic_1.0.tar.gz

echo conda install -c bioconda igv-reports
conda install -c bioconda igv-reports

echo "Creating a new softlink"
echo unlink ~/.local/bin/create_datauri
unlink ~/.local/bin/create_datauri

echo ln -s $PWD/scripts/create_datauri ~/.local/bin/
ln -s $PWD/scripts/create_datauri ~/.local/bin/
